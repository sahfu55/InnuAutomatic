package com.innu.automatic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070708)
private val Panel = Color(0xFF101011)
private val Panel2 = Color(0xFF151416)
private val Purple = Color(0xFF8064C6)
private val PurpleSoft = Color(0xFF2B243E)
private val TextMain = Color(0xFFF4F2F5)
private val TextMuted = Color(0xFF8C8991)
private val Border = Color(0xFF29272B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { InnuAutomaticApp() }
    }
}

private enum class Route { HOME, PASS, GAMES, SELLERS, SETTINGS, DEVICE, AUTOMATION, RUNTIME, ABOUT }

@Composable
fun InnuAutomaticApp() {
    var selected by remember { mutableIntStateOf(0) }
    var route by remember { mutableStateOf(Route.HOME) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var runtimeRunning by remember { mutableStateOf(false) }
    var deviceConnected by remember { mutableStateOf(true) }
    var notifications by remember { mutableStateOf(true) }
    var sound by remember { mutableStateOf(true) }
    var vibration by remember { mutableStateOf(false) }
    var autoStart by remember { mutableStateOf(false) }
    var selectedGame by remember { mutableStateOf("Practice") }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Scaffold(containerColor = Bg, bottomBar = {
                if (route in listOf(Route.HOME, Route.PASS, Route.GAMES, Route.SELLERS, Route.SETTINGS)) {
                    BottomNav(selected) { index ->
                        selected = index
                        route = when (index) {
                            0 -> Route.HOME
                            1 -> Route.PASS
                            2 -> Route.GAMES
                            3 -> Route.SELLERS
                            else -> Route.SETTINGS
                        }
                    }
                }
            }) { padding ->
                val cm = Modifier.padding(padding)
                when (route) {
                    Route.HOME -> HomeScreen(cm, deviceConnected, runtimeRunning,
                        onMessage = { dialog = "Messaging is available in the local test UI. Backend/login can be connected later." },
                        onInfo = { route = Route.ABOUT }, onManage = { route = Route.DEVICE },
                        onAutomation = { route = Route.AUTOMATION }, onRuntime = { route = Route.RUNTIME },
                        onShowcase = { route = Route.GAMES })
                    Route.PASS -> PassScreen(cm, onMessage = { dialog = "Pass activation is shown in local test mode. Real activation can be connected later." }, onActivate = { dialog = "Premium activation is disabled in Phase 1 test mode." })
                    Route.GAMES -> GamesScreen(cm, selectedGame, { selectedGame = it }, { route = Route.RUNTIME })
                    Route.SELLERS -> SellersScreen(cm, { dialog = "Seller messaging is ready for backend integration." }, { dialog = "Official seller: @INNUxS" })
                    Route.SETTINGS -> SettingsScreen(cm, notifications, sound, vibration, autoStart,
                        { notifications = it }, { sound = it }, { vibration = it }, { autoStart = it }, { dialog = it }, { route = Route.ABOUT })
                    Route.DEVICE -> DeviceScreen(cm, deviceConnected, { route = Route.HOME }, { deviceConnected = it })
                    Route.AUTOMATION -> AutomationScreen(cm, { route = Route.HOME }, { route = Route.RUNTIME })
                    Route.RUNTIME -> RuntimeScreen(cm, runtimeRunning, { route = Route.HOME }, { runtimeRunning = it })
                    Route.ABOUT -> AboutScreen(cm, { route = Route.HOME })
                }
            }
            dialog?.let { message ->
                AlertDialog(onDismissRequest = { dialog = null }, title = { Text("Innu Automatic") }, text = { Text(message) }, confirmButton = { TextButton(onClick = { dialog = null }) { Text("OK") } })
            }
        }
    }
}

@Composable private fun Header(title: String, onMessage: () -> Unit, onInfo: () -> Unit, showBack: Boolean = false, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (showBack) { HeaderIcon(Icons.Outlined.ArrowBack) { onBack?.invoke() }; Spacer(Modifier.width(10.dp)) }
        Surface(shape = RoundedCornerShape(50), color = Color(0xFF151318), border = BorderStroke(1.dp, Border)) {
            Row(Modifier.padding(start = 7.dp, end = 10.dp, top = 5.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.innu_logo), null, Modifier.size(24.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                Spacer(Modifier.width(7.dp)); Text("Innu Automatic", color = TextMain, fontSize = 9.sp, fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.width(14.dp)); Text(title, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        HeaderIcon(Icons.Outlined.ChatBubbleOutline, onMessage); Spacer(Modifier.width(7.dp)); HeaderIcon(Icons.Outlined.Info, onInfo)
    }
}

@Composable private fun HeaderIcon(icon: ImageVector, onClick: () -> Unit) {
    Surface(shape = CircleShape, color = Color(0xFF101012), border = BorderStroke(1.dp, Border), modifier = Modifier.clickable { onClick() }) {
        Box(Modifier.size(32.dp), contentAlignment = Alignment.Center) { Icon(icon, null, tint = TextMuted, modifier = Modifier.size(15.dp)) }
    }
}

@Composable private fun HomeScreen(modifier: Modifier, deviceConnected: Boolean, runtimeRunning: Boolean, onMessage: () -> Unit, onInfo: () -> Unit, onManage: () -> Unit, onAutomation: () -> Unit, onRuntime: () -> Unit, onShowcase: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        Header("Home.", onMessage, onInfo)
        Column(Modifier.padding(horizontal = 16.dp)) {
            Surface(shape = RoundedCornerShape(20.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.innu_logo), null, Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)), contentScale = ContentScale.Crop)
                        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("Innu Automatic", color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text(if (runtimeRunning) "Automation running" else "Automation engine", color = TextMuted, fontSize = 11.sp) }
                        StatusPill(if (runtimeRunning) "Running" else "Ready")
                    }
                    Spacer(Modifier.height(18.dp)); HorizontalDivider(color = Border); Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("1 device", color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Text(if (deviceConnected) "This device is available" else "This device is offline", color = TextMuted, fontSize = 10.sp) }
                        OutlinedButton(onClick = onManage, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Border), contentPadding = PaddingValues(horizontal = 15.dp), modifier = Modifier.height(36.dp)) { Text("Manage", fontSize = 11.sp) }
                    }
                }
            }
            Spacer(Modifier.height(16.dp)); SectionLabel("QUICK ACTIONS"); Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                ActionCard(Icons.Outlined.AutoAwesome, "Automation", "Open", Modifier.weight(1f), onAutomation)
                ActionCard(Icons.Outlined.PlayArrow, "Runtime", if (runtimeRunning) "Running" else "Launch", Modifier.weight(1f), onRuntime)
            }
            Spacer(Modifier.height(9.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                ActionCard(Icons.Outlined.EmojiEvents, "Games", "Open", Modifier.weight(1f), onShowcase)
                ActionCard(Icons.Outlined.Verified, "Pass", "View", Modifier.weight(1f)) { }
            }
            Spacer(Modifier.height(16.dp)); SectionLabel("SHOWCASE"); Spacer(Modifier.height(8.dp))
            Surface(shape = RoundedCornerShape(18.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth().clickable { onShowcase() }) {
                Column {
                    Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)).background(Brush.linearGradient(listOf(Color(0xFF28232F), Color(0xFF0B0B0D))))) {
                        Text("PRECISION,\nMADE VISIBLE.", color = TextMain, fontSize = 18.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterStart).padding(start = 18.dp))
                        Surface(Modifier.size(72.dp).align(Alignment.CenterEnd).offset(x = (-28).dp), shape = CircleShape, color = PurpleSoft, border = BorderStroke(1.dp, Purple.copy(alpha = .55f))) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Gesture, null, tint = Color(0xFFBCA8F4), modifier = Modifier.size(30.dp)) } }
                    }
                    Column(Modifier.padding(14.dp)) { Text("Local automation playground", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text("Explore workflows, runtime status and practice screens.", color = TextMuted, fontSize = 10.sp) }
                }
            }
            Spacer(Modifier.height(16.dp)); SectionLabel("STATUS"); Spacer(Modifier.height(8.dp)); InfoCard(Icons.Outlined.Security, "Local test mode", "No login or remote account required"); Spacer(Modifier.height(8.dp)); InfoCard(Icons.Outlined.Storage, "Data", "Settings and demo state stay on this device")
        }
    }
}

@Composable private fun PassScreen(modifier: Modifier, onMessage: () -> Unit, onActivate: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) { Header("Pass.", onMessage, { onMessage() }); Column(Modifier.padding(horizontal = 16.dp)) {
        Surface(shape = RoundedCornerShape(20.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Premium Pass", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Unlock premium-ready UI", color = TextMuted, fontSize = 10.sp) }; StatusPill("Inactive") }; Spacer(Modifier.height(22.dp)); Row(verticalAlignment = Alignment.Bottom) { Text("0", color = TextMain, fontSize = 34.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(8.dp)); Text("DAYS REMAINING", color = TextMuted, fontSize = 7.sp, modifier = Modifier.padding(bottom = 7.dp)) } } }
        Spacer(Modifier.height(14.dp)); Button(onClick = onActivate, modifier = Modifier.fillMaxWidth().height(43.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = PurpleSoft)) { Text("Activate pass", fontSize = 11.sp) }
        Spacer(Modifier.height(18.dp)); SectionLabel("MEMBERSHIP DETAILS"); Spacer(Modifier.height(8.dp)); Surface(shape = RoundedCornerShape(18.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { DetailRow("Activated", "—"); DetailRow("Expiry", "—"); DetailRow("Key ID", "—"); DetailRow("Seller", "@INNUxS") } }
    } }
}

@Composable private fun GamesScreen(modifier: Modifier, selected: String, onSelect: (String) -> Unit, onRun: () -> Unit) {
    val games = listOf("Practice", "Reaction", "Tracking", "Tap Test")
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) { Header("Games.", {}, {}); Column(Modifier.padding(horizontal = 16.dp)) {
        Surface(shape = RoundedCornerShape(18.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("Practice lab", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Safe local mini-games for testing the interface and runtime flow.", color = TextMuted, fontSize = 10.sp); Spacer(Modifier.height(14.dp)); games.forEach { name -> GameRow(name, selected == name) { onSelect(name) } } } }
        Spacer(Modifier.height(12.dp)); Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF201B31), border = BorderStroke(1.dp, Purple.copy(.45f)), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) { Text("SELECTED", color = TextMuted, fontSize = 8.sp); Text(selected, color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); Button(onClick = onRun, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(11.dp), colors = ButtonDefaults.buttonColors(containerColor = PurpleSoft)) { Text("Run local test", fontSize = 11.sp) } } }
    } }
}

@Composable private fun GameRow(name: String, selected: Boolean, onClick: () -> Unit) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (selected) PurpleSoft else Color.Transparent).clickable { onClick() }.padding(11.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Outlined.SportsEsports, null, tint = if (selected) Color(0xFFBCA8F4) else TextMuted, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text(name, color = TextMain, fontSize = 11.sp, modifier = Modifier.weight(1f)); if (selected) Icon(Icons.Outlined.Check, null, tint = Color(0xFFBCA8F4), modifier = Modifier.size(16.dp)) } }

@Composable private fun SellersScreen(modifier: Modifier, onMessage: () -> Unit, onContact: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) { Header("Sellers.", onMessage, onMessage); Column(Modifier.padding(horizontal = 16.dp)) {
        Button(onClick = onContact, modifier = Modifier.fillMaxWidth().height(42.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = PurpleSoft)) { Text("Contact official seller", fontSize = 11.sp) }
        Spacer(Modifier.height(16.dp)); Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF201B31), border = BorderStroke(1.dp, Purple.copy(.45f)), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) { Text("OFFICIAL SELLER", color = TextMuted, fontSize = 8.sp); Text("@INNUxS", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Global • Innu Automatic seller", color = TextMuted, fontSize = 10.sp) } }
        Spacer(Modifier.height(14.dp)); SectionLabel("SELLER NETWORK"); Spacer(Modifier.height(8.dp)); SellerCard(onContact)
    } }
}

@Composable private fun SettingsScreen(modifier: Modifier, notifications: Boolean, sound: Boolean, vibration: Boolean, autoStart: Boolean, setNotifications: (Boolean) -> Unit, setSound: (Boolean) -> Unit, setVibration: (Boolean) -> Unit, setAutoStart: (Boolean) -> Unit, onMessage: (String) -> Unit, onAbout: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) { Header("Settings.", { onMessage("Messages are in local test mode.") }, { onAbout() }); Column(Modifier.padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(4.dp)); SectionLabel("PREFERENCES"); Spacer(Modifier.height(7.dp)); SettingsGroup { SettingToggle(Icons.Outlined.Notifications, "Notifications", notifications, setNotifications); SettingToggle(Icons.Outlined.VolumeUp, "Sound", sound, setSound); SettingToggle(Icons.Outlined.Vibration, "Vibration", vibration, setVibration); SettingToggle(Icons.Outlined.PlayCircle, "Auto start runtime", autoStart, setAutoStart) }
        Spacer(Modifier.height(16.dp)); SectionLabel("APP"); Spacer(Modifier.height(7.dp)); SettingsGroup { SettingRow(Icons.Outlined.Description, "Version", "1.0"); SettingRow(Icons.Outlined.Memory, "Architecture", "ARM64"); SettingRow(Icons.Outlined.Security, "Mode", "Local test"); SettingRow(Icons.Outlined.Info, "About", "›", onAbout) }
        Spacer(Modifier.height(16.dp)); SectionLabel("DATA"); Spacer(Modifier.height(7.dp)); SettingsGroup { SettingRow(Icons.Outlined.Share, "Export logs", "›") { onMessage("Demo log export is ready for a future file/export integration.") }; SettingRow(Icons.Outlined.Delete, "Clear local demo data", "›") { onMessage("Local demo data cleared.") } }
        Spacer(Modifier.height(14.dp)); Text("© 2026 Innu Automatic", color = TextMuted, fontSize = 8.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    } }
}

@Composable private fun DeviceScreen(modifier: Modifier, connected: Boolean, onBack: () -> Unit, onToggle: (Boolean) -> Unit) { Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Header("Device.", {}, {}, true, onBack); Column(Modifier.padding(horizontal = 16.dp)) { InfoCard(Icons.Outlined.PhoneAndroid, "This device", if (connected) "Connected and ready" else "Offline"); Spacer(Modifier.height(12.dp)); SettingsGroup { SettingToggle(Icons.Outlined.Bluetooth, "Device connected", connected, onToggle) }; Spacer(Modifier.height(12.dp)); InfoCard(Icons.Outlined.Bolt, "Runtime access", "Local test controls only") } } }

@Composable private fun AutomationScreen(modifier: Modifier, onBack: () -> Unit, onRun: () -> Unit) { Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Header("Automation.", {}, {}, true, onBack); Column(Modifier.padding(horizontal = 16.dp)) { InfoCard(Icons.Outlined.AutoAwesome, "Workflow", "Create and test a local automation sequence"); Spacer(Modifier.height(12.dp)); SettingsGroup { SettingRow(Icons.Outlined.TouchApp, "Step 1", "Prepare"); SettingRow(Icons.Outlined.Timer, "Step 2", "Wait"); SettingRow(Icons.Outlined.PlayArrow, "Step 3", "Run test") }; Spacer(Modifier.height(12.dp)); Button(onClick = onRun, modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = PurpleSoft)) { Text("Run workflow", fontSize = 11.sp) } } } }

@Composable private fun RuntimeScreen(modifier: Modifier, running: Boolean, onBack: () -> Unit, onToggle: (Boolean) -> Unit) { Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Header("Runtime.", {}, {}, true, onBack); Column(Modifier.padding(horizontal = 16.dp)) { Surface(shape = RoundedCornerShape(20.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text(if (running) "Runtime active" else "Runtime stopped", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(if (running) "Local test workflow is running." else "Ready to start a local test workflow.", color = TextMuted, fontSize = 10.sp); Spacer(Modifier.height(16.dp)); StatusPill(if (running) "RUNNING" else "IDLE") } }; Spacer(Modifier.height(14.dp)); Button(onClick = { onToggle(!running) }, modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFF35202A) else PurpleSoft)) { Text(if (running) "Stop runtime" else "Start runtime", fontSize = 11.sp) }; Spacer(Modifier.height(14.dp)); InfoCard(Icons.Outlined.Terminal, "Runtime log", if (running) "step 1/3 • local test" else "No active run") } } }

@Composable private fun AboutScreen(modifier: Modifier, onBack: () -> Unit) { Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Header("About.", {}, {}, true, onBack); Column(Modifier.padding(horizontal = 16.dp)) { Surface(shape = RoundedCornerShape(20.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) { Image(painterResource(R.drawable.innu_logo), null, Modifier.size(78.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.Crop); Spacer(Modifier.height(12.dp)); Text("Innu Automatic", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Version 1.0 • Phase 1", color = TextMuted, fontSize = 10.sp); Spacer(Modifier.height(14.dp)); Text("A locally testable automation-style Android UI. Login/backend integration can be added later.", color = TextMuted, fontSize = 11.sp) } }; Spacer(Modifier.height(12.dp)); InfoCard(Icons.Outlined.Code, "Implementation", "Original Kotlin + Jetpack Compose implementation"); Spacer(Modifier.height(8.dp)); InfoCard(Icons.Outlined.Shield, "Safety", "No game injection, cheating or bypass behavior") } } }

@Composable private fun SectionLabel(text: String) = Text(text, color = TextMuted, fontSize = 8.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
@Composable private fun StatusPill(text: String) { Surface(shape = RoundedCornerShape(50), color = Color(0xFF18221C)) { Text(text, color = Color(0xFF88A892), fontSize = 8.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) } }
@Composable private fun ActionCard(icon: ImageVector, title: String, action: String, modifier: Modifier, onClick: () -> Unit) { Surface(modifier.height(78.dp).then(modifier).clickable { onClick() }, shape = RoundedCornerShape(16.dp), color = Panel, border = BorderStroke(1.dp, Border)) { Column(Modifier.padding(12.dp)) { Icon(icon, null, tint = Color(0xFFA48BDF), modifier = Modifier.size(19.dp)); Spacer(Modifier.height(6.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Text(title, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(action, color = TextMuted, fontSize = 9.sp) } } } }
@Composable private fun InfoCard(icon: ImageVector, title: String, body: String) { Surface(shape = RoundedCornerShape(16.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { SettingIcon(icon); Spacer(Modifier.width(11.dp)); Column { Text(title, color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text(body, color = TextMuted, fontSize = 10.sp) } } } }
@Composable private fun DetailRow(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 9.dp)) { Text(label, color = TextMain, fontSize = 11.sp, modifier = Modifier.weight(1f)); Text(value, color = TextMuted, fontSize = 10.sp) } }
@Composable private fun SellerCard(onContact: () -> Unit) { Surface(shape = RoundedCornerShape(16.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(42.dp), shape = CircleShape, color = Color(0xFF494131)) { Box(contentAlignment = Alignment.Center) { Text("IA", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold) } }; Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text("@INNUxS", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text("🌐 Global • Official seller", color = TextMuted, fontSize = 9.sp) }; TextButton(onClick = onContact) { Text("Contact", fontSize = 9.sp) } } } }
@Composable private fun SettingIcon(icon: ImageVector) { Surface(Modifier.size(34.dp), shape = RoundedCornerShape(10.dp), color = Color(0xFF1A1820)) { Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color(0xFF9A83D5), modifier = Modifier.size(17.dp)) } } }
@Composable private fun SettingsGroup(content: @Composable ColumnScope.() -> Unit) { Surface(shape = RoundedCornerShape(16.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Column(content = content) } }
@Composable private fun SettingRow(icon: ImageVector, title: String, value: String, onClick: (() -> Unit)? = null) { Row(Modifier.fillMaxWidth().clickable(enabled = onClick != null) { onClick?.invoke() }.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) { SettingIcon(icon); Spacer(Modifier.width(10.dp)); Text(title, color = TextMain, fontSize = 11.sp, modifier = Modifier.weight(1f)); Text(value, color = TextMuted, fontSize = 9.sp) } }
@Composable private fun SettingToggle(icon: ImageVector, title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) { SettingIcon(icon); Spacer(Modifier.width(10.dp)); Text(title, color = TextMain, fontSize = 11.sp, modifier = Modifier.weight(1f)); Switch(checked = checked, onCheckedChange = onCheckedChange, modifier = Modifier.height(24.dp)) } }
@Composable private fun BottomNav(selected: Int, onSelected: (Int) -> Unit) { Surface(color = Bg) { Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 5.dp, bottom = 8.dp).height(48.dp).clip(RoundedCornerShape(30.dp)).background(Color(0xFF0E0E10)).padding(4.dp), verticalAlignment = Alignment.CenterVertically) { val items = listOf(Icons.Outlined.Home, Icons.Outlined.WorkspacePremium, Icons.Outlined.EmojiEvents, Icons.Outlined.Storefront, Icons.Outlined.Settings); items.forEachIndexed { index, icon -> Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(24.dp)).background(if (selected == index) PurpleSoft else Color.Transparent), contentAlignment = Alignment.Center) { IconButton(onClick = { onSelected(index) }) { Icon(icon, null, tint = if (selected == index) Color(0xFFBCA8F4) else Color(0xFF706D74), modifier = Modifier.size(17.dp)) } } } } } }
