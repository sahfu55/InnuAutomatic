package com.innu.automatic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070708)
private val Panel = Color(0xFF101011)
private val Panel2 = Color(0xFF151416)
private val Purple = Color(0xFF8064C6)
private val PurpleSoft = Color(0xFF2B243E)
private val TextMain = Color(0xFFF4F2F5)
private val TextMuted = Color(0xFF8C8991)
private val Border = Color(0xFF29272B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { InnuAutomaticApp() }
    }
}

private enum class Route { HOME, PASS, SELLERS, SETTINGS, DEVICE, AUTOMATION, RUNTIME }

@Composable
fun InnuAutomaticApp() {
    var selected by remember { mutableIntStateOf(0) }
    var route by remember { mutableStateOf(Route.HOME) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var runtimeRunning by remember { mutableStateOf(false) }
    var deviceConnected by remember { mutableStateOf(true) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Scaffold(containerColor = Bg,
                bottomBar = {
                    if (route == Route.HOME || route == Route.PASS || route == Route.SELLERS || route == Route.SETTINGS) {
                        BottomNav(selected) {
                            selected = it
                            route = when (it) { 0 -> Route.HOME; 1 -> Route.PASS; 2 -> Route.SELLERS; else -> Route.SETTINGS }
                        }
                    }
                }) { padding ->
                val contentModifier = Modifier.padding(padding)
                when (route) {
                    Route.HOME -> HomeScreen(contentModifier,
                        deviceConnected = deviceConnected,
                        runtimeRunning = runtimeRunning,
                        onMessage = { dialog = "Messaging will be connected after login/backend is added." },
                        onInfo = { dialog = "Innu Automatic • Phase 1 local test build" },
                        onManage = { route = Route.DEVICE },
                        onAutomation = { route = Route.AUTOMATION },
                        onRuntime = { route = Route.RUNTIME },
                        onShowcase = { route = Route.AUTOMATION })
                    Route.PASS -> PassScreen(contentModifier, onMessage = { dialog = "Premium activation will be connected after the login/backend phase." }, onActivate = { dialog = "Premium activation is disabled in Phase 1 test mode." })
                    Route.SELLERS -> SellersScreen(contentModifier, onMessage = { dialog = "Seller messaging will be connected later." }, onContact = { dialog = "Contact flow is ready for backend integration." })
                    Route.SETTINGS -> SettingsScreen(contentModifier, onMessage = { dialog = it })
                    Route.DEVICE -> DeviceScreen(contentModifier, connected = deviceConnected, onBack = { route = Route.HOME }, onToggle = { deviceConnected = it })
                    Route.AUTOMATION -> AutomationScreen(contentModifier, onBack = { route = Route.HOME }, onRun = { route = Route.RUNTIME })
                    Route.RUNTIME -> RuntimeScreen(contentModifier, running = runtimeRunning, onBack = { route = Route.HOME }, onToggle = { runtimeRunning = it })
                }
            }
            dialog?.let { message ->
                AlertDialog(onDismissRequest = { dialog = null }, title = { Text("Innu Automatic") }, text = { Text(message) }, confirmButton = { TextButton(onClick = { dialog = null }) { Text("OK") } })
            }
        }
    }
}

@Composable private fun Header(title: String, onMessage: () -> Unit, onInfo: () -> Unit, showBack: Boolean = false, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (showBack) { HeaderIcon(Icons.Outlined.ArrowBack, { onBack?.invoke() }); Spacer(Modifier.width(10.dp)) }
        Surface(shape = RoundedCornerShape(50), color = Color(0xFF151318), border = BorderStroke(1.dp, Border)) {
            Row(Modifier.padding(start = 7.dp, end = 10.dp, top = 5.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.innu_logo), null, Modifier.size(24.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                Spacer(Modifier.width(7.dp)); Text("Innu Automatic", color = TextMain, fontSize = 9.sp, fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.width(14.dp)); Text(title, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        HeaderIcon(Icons.Outlined.ChatBubbleOutline, onMessage); Spacer(Modifier.width(7.dp)); HeaderIcon(Icons.Outlined.Info, onInfo)
    }
}

@Composable private fun HeaderIcon(icon: ImageVector, onClick: () -> Unit) {
    Surface(shape = CircleShape, color = Color(0xFF101012), border = BorderStroke(1.dp, Border), modifier = Modifier.clickable { onClick() }) { Box(Modifier.size(32.dp), contentAlignment = Alignment.Center) { Icon(icon, null, tint = TextMuted, modifier = Modifier.size(15.dp)) } }
}

@Composable private fun HomeScreen(modifier: Modifier, deviceConnected: Boolean, runtimeRunning: Boolean, onMessage: () -> Unit, onInfo: () -> Unit, onManage: () -> Unit, onAutomation: () -> Unit, onRuntime: () -> Unit, onShowcase: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        Header("Home.", onMessage, onInfo)
        Column(Modifier.padding(horizontal = 16.dp)) {
            Surface(shape = RoundedCornerShape(20.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.innu_logo), null, Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)), contentScale = ContentScale.Crop)
                        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("Innu Automatic", color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text(if (runtimeRunning) "Automation running" else "Automation engine", color = TextMuted, fontSize = 11.sp) }
                        StatusPill(if (runtimeRunning) "Running" else "Ready")
                    }
                    Spacer(Modifier.height(18.dp)); HorizontalDivider(color = Border); Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("1 device", color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Text(if (deviceConnected) "This device is available" else "This device is offline", color = TextMuted, fontSize = 10.sp) }
                        OutlinedButton(onClick = onManage, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Border), contentPadding = PaddingValues(horizontal = 15.dp), modifier = Modifier.height(36.dp)) { Text("Manage", fontSize = 11.sp) }
                    }
                }
            }
            Spacer(Modifier.height(16.dp)); SectionLabel("QUICK ACTIONS"); Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                ActionCard(Icons.Outlined.AutoAwesome, "Automation", "Open", Modifier.weight(1f), onAutomation)
                ActionCard(Icons.Outlined.PlayArrow, "Runtime", if (runtimeRunning) "Running" else "Launch", Modifier.weight(1f), onRuntime)
            }
            Spacer(Modifier.height(16.dp)); SectionLabel("SHOWCASE"); Spacer(Modifier.height(8.dp))
            Surface(shape = RoundedCornerShape(18.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth().clickable { onShowcase() }) {
                Column {
                    Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)).background(Brush.linearGradient(listOf(Color(0xFF28232F), Color(0xFF0B0B0D))))) {
                        Text("PRECISION,\nMADE VISIBLE.", color = TextMain, fontSize = 18.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterStart).padding(start = 18.dp))
                        Surface(Modifier.size(72.dp).align(Alignment.CenterEnd).offset(x = (-28).dp), shape = CircleShape, color = PurpleSoft, border = BorderStroke(1.dp, Purple.copy(alpha = .55f))) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Gesture, null, tint = Color(0xFFBCA8F4), modifier = Modifier.size(30.dp)) } }
                    }
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Automation tools", color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.SemiBold); Text("Build and run your first workflow", color = TextMuted, fontSize = 10.sp) }; Icon(Icons.Outlined.ArrowForward, null, tint = TextMuted, modifier = Modifier.size(18.dp)) }
                }
            }
            Spacer(Modifier.height(14.dp)); InfoCard(Icons.Outlined.Security, "Local test mode", "Login is disabled for Phase 1 testing")
        }
    }
}

@Composable private fun DeviceScreen(modifier: Modifier, connected: Boolean, onBack: () -> Unit, onToggle: (Boolean) -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Device.", {}, {}, true, onBack)
        Column(Modifier.padding(horizontal = 16.dp)) {
            Surface(shape = RoundedCornerShape(20.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { SettingIcon(Icons.Outlined.Smartphone); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("This device", color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text("Local device profile", color = TextMuted, fontSize = 10.sp) }; StatusPill(if (connected) "Online" else "Offline") }
                    Spacer(Modifier.height(16.dp)); HorizontalDivider(color = Border); Spacer(Modifier.height(10.dp));
                    DetailRow("Connection", if (connected) "Available" else "Disabled"); DetailRow("Mode", "Local test"); DetailRow("Login", "Not required")
                    Button(onClick = { onToggle(!connected) }, modifier = Modifier.fillMaxWidth().height(42.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = PurpleSoft)) { Text(if (connected) "Disconnect device" else "Connect device", fontSize = 11.sp) }
                }
            }
        }
    }
}

@Composable private fun AutomationScreen(modifier: Modifier, onBack: () -> Unit, onRun: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Automation.", {}, {}, true, onBack)
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text("Create workflow", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Build a local test automation without login.", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(16.dp)); AutomationStep("1", Icons.Outlined.TouchApp, "Trigger", "When the workflow starts"); AutomationStep("2", Icons.Outlined.Tune, "Action", "Run selected automation"); AutomationStep("3", Icons.Outlined.CheckCircle, "Result", "Show execution status")
            Spacer(Modifier.height(14.dp)); Button(onClick = onRun, modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = PurpleSoft)) { Icon(Icons.Outlined.PlayArrow, null); Spacer(Modifier.width(7.dp)); Text("Run test automation", fontSize = 11.sp) }
        }
    }
}

@Composable private fun AutomationStep(number: String, icon: ImageVector, title: String, body: String) {
    Surface(shape = RoundedCornerShape(16.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(32.dp), shape = CircleShape, color = PurpleSoft) { Box(contentAlignment = Alignment.Center) { Text(number, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.Bold) } }; Spacer(Modifier.width(11.dp)); SettingIcon(icon); Spacer(Modifier.width(10.dp)); Column { Text(title, color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text(body, color = TextMuted, fontSize = 9.sp) } }
    }
}

@Composable private fun RuntimeScreen(modifier: Modifier, running: Boolean, onBack: () -> Unit, onToggle: (Boolean) -> Unit) {
    Column(modifier.fillMaxSize()) {
        Header("Runtime.", {}, {}, true, onBack)
        Column(Modifier.padding(horizontal = 16.dp)) {
            Surface(shape = RoundedCornerShape(20.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) { SettingIcon(Icons.Outlined.PlayCircle); Spacer(Modifier.height(12.dp)); Text(if (running) "Automation is running" else "Runtime is idle", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(if (running) "Local test execution in progress" else "Ready to start a local test run", color = TextMuted, fontSize = 10.sp); Spacer(Modifier.height(18.dp)); Button(onClick = { onToggle(!running) }, modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFF402626) else PurpleSoft)) { Text(if (running) "Stop automation" else "Start automation", fontSize = 11.sp) } }
            }
        }
    }
}

@Composable private fun PassScreen(modifier: Modifier, onMessage: () -> Unit, onActivate: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) { Header("Pass.", onMessage, onMessage); Column(Modifier.padding(horizontal = 16.dp)) {
        Surface(shape = RoundedCornerShape(22.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Box(Modifier.height(195.dp).fillMaxWidth().background(Brush.radialGradient(listOf(PurpleSoft, Panel, Bg)))) { Column(Modifier.padding(18.dp)) { Text("PREMIUM MEMBERSHIP", color = TextMuted, fontSize = 8.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold); Text("Premium Pass", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Row(verticalAlignment = Alignment.Bottom) { Text("0", color = TextMain, fontSize = 34.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(8.dp)); Text("DAYS REMAINING", color = TextMuted, fontSize = 7.sp, modifier = Modifier.padding(bottom = 7.dp)) } }; StatusPill("Inactive") } }
        Spacer(Modifier.height(14.dp)); Button(onClick = onActivate, modifier = Modifier.fillMaxWidth().height(43.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = PurpleSoft)) { Text("Activate pass", fontSize = 11.sp) }
        Spacer(Modifier.height(18.dp)); SectionLabel("MEMBERSHIP DETAILS"); Spacer(Modifier.height(8.dp)); Surface(shape = RoundedCornerShape(18.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { DetailRow("Activated", "—"); DetailRow("Expiry", "—"); DetailRow("Key ID", "—"); DetailRow("Seller", "—") } }
    } }
}

@Composable private fun SellersScreen(modifier: Modifier, onMessage: () -> Unit, onContact: () -> Unit) {
    var selected by remember { mutableStateOf("All") }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) { Header("Sellers.", onMessage, onMessage); Column(Modifier.padding(horizontal = 16.dp)) {
        Button(onClick = onContact, modifier = Modifier.fillMaxWidth().height(42.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = PurpleSoft)) { Text("Find sellers", fontSize = 11.sp) }
        Spacer(Modifier.height(16.dp)); Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF201B31), border = BorderStroke(1.dp, Purple.copy(.45f)), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) { Text("1 seller", color = TextMuted, fontSize = 8.sp); Text("Official seller network", color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text("Choose a territory and contact the right seller directly.", color = TextMuted, fontSize = 10.sp) } }
        Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterPill("All · 1", selected == "All") { selected = "All" }; FilterPill("🌐 Global · 1", selected == "Global") { selected = "Global" } }
        Spacer(Modifier.height(18.dp)); SectionLabel("ALL"); Spacer(Modifier.height(8.dp)); SellerCard(onContact)
    } }
}

@Composable private fun SettingsScreen(modifier: Modifier, onMessage: (String) -> Unit) {
    var notifications by remember { mutableStateOf(true) }; var dumpLogs by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) { Header("Settings.", { onMessage("Messages will be connected later.") }, { onMessage("Innu Automatic Phase 1 • Local test build") }); Column(Modifier.padding(horizontal = 16.dp)) {
        Surface(shape = RoundedCornerShape(18.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) { SettingIcon(Icons.Outlined.AccountTree); Column(Modifier.weight(1f)) { Text("Google services", color = TextMain, fontSize = 12.sp); Text("Not installed", color = TextMuted, fontSize = 9.sp) }; OutlinedButton(onClick = { onMessage("Google services setup is not required in Phase 1.") }, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 13.dp), modifier = Modifier.height(34.dp)) { Text("Set up", fontSize = 10.sp) } } }
        Spacer(Modifier.height(16.dp)); SectionLabel("PREFERENCES"); Spacer(Modifier.height(7.dp)); SettingsGroup { SettingToggle(Icons.Outlined.Notifications, "Notifications", notifications) { notifications = it }; SettingToggle(Icons.Outlined.Terminal, "Dump logs", dumpLogs) { dumpLogs = it } }
        Spacer(Modifier.height(16.dp)); SectionLabel("APP"); Spacer(Modifier.height(7.dp)); SettingsGroup { SettingRow(Icons.Outlined.Description, "Version", "1.0"); SettingRow(Icons.Outlined.Memory, "Architecture", "ARM64"); SettingRow(Icons.Outlined.Gavel, "Legal", "›") }
        Spacer(Modifier.height(16.dp)); SectionLabel("LOGS"); Spacer(Modifier.height(7.dp)); SettingsGroup { SettingRow(Icons.Outlined.Share, "Share logs", "›", { onMessage("Log sharing is ready for a future backend/export integration.") }); SettingRow(Icons.Outlined.Delete, "Clear logs", "9.9 kB", { onMessage("Logs cleared in local test mode.") }) }
        Spacer(Modifier.height(8.dp)); Text("© 2026 Innu Automatic. All rights reserved.", color = TextMuted, fontSize = 8.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    } }
}

@Composable private fun SectionLabel(text: String) = Text(text, color = TextMuted, fontSize = 8.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
@Composable private fun StatusPill(text: String) { Surface(shape = RoundedCornerShape(50), color = Color(0xFF18221C), modifier = Modifier.padding(12.dp)) { Text(text, color = Color(0xFF88A892), fontSize = 8.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) } }
@Composable private fun ActionCard(icon: ImageVector, title: String, action: String, modifier: Modifier, onClick: () -> Unit) { Surface(modifier.height(78.dp).then(modifier).clickable { onClick() }, shape = RoundedCornerShape(16.dp), color = Panel, border = BorderStroke(1.dp, Border)) { Column(Modifier.padding(12.dp)) { Icon(icon, null, tint = Color(0xFFA48BDF), modifier = Modifier.size(19.dp)); Spacer(Modifier.height(6.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Text(title, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(action, color = TextMuted, fontSize = 9.sp) } } } }
@Composable private fun InfoCard(icon: ImageVector, title: String, body: String) { Surface(shape = RoundedCornerShape(16.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { SettingIcon(icon); Spacer(Modifier.width(11.dp)); Column { Text(title, color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text(body, color = TextMuted, fontSize = 10.sp) } } } }
@Composable private fun DetailRow(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 9.dp)) { Text(label, color = TextMain, fontSize = 11.sp, modifier = Modifier.weight(1f)); Text(value, color = TextMuted, fontSize = 10.sp) } }
@Composable private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) { Surface(shape = RoundedCornerShape(50), color = if (selected) PurpleSoft else Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.clickable { onClick() }) { Text(text, color = if (selected) TextMain else TextMuted, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp)) } }
@Composable private fun SellerCard(onContact: () -> Unit) { Surface(shape = RoundedCornerShape(16.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(42.dp), shape = CircleShape, color = Color(0xFF494131)) { Box(contentAlignment = Alignment.Center) { Text("IA", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold) } }; Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text("Innu Official", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text("🌐 Global", color = TextMuted, fontSize = 9.sp) }; TextButton(onClick = onContact) { Text("Contact", fontSize = 9.sp) } } } }
@Composable private fun SettingIcon(icon: ImageVector) { Surface(Modifier.size(34.dp), shape = RoundedCornerShape(10.dp), color = Color(0xFF1A1820)) { Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color(0xFF9A83D5), modifier = Modifier.size(17.dp)) } } }
@Composable private fun SettingsGroup(content: @Composable ColumnScope.() -> Unit) { Surface(shape = RoundedCornerShape(16.dp), color = Panel, border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) { Column(content = content) } }
@Composable private fun SettingRow(icon: ImageVector, title: String, value: String, onClick: (() -> Unit)? = null) { Row(Modifier.fillMaxWidth().clickable(enabled = onClick != null) { onClick?.invoke() }.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) { SettingIcon(icon); Spacer(Modifier.width(10.dp)); Text(title, color = TextMain, fontSize = 11.sp, modifier = Modifier.weight(1f)); Text(value, color = TextMuted, fontSize = 9.sp) } }
@Composable private fun SettingToggle(icon: ImageVector, title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) { SettingIcon(icon); Spacer(Modifier.width(10.dp)); Text(title, color = TextMain, fontSize = 11.sp, modifier = Modifier.weight(1f)); Switch(checked = checked, onCheckedChange = onCheckedChange, modifier = Modifier.height(24.dp)) } }
@Composable private fun BottomNav(selected: Int, onSelected: (Int) -> Unit) { Surface(color = Bg) { Row(Modifier.fillMaxWidth().padding(start = 40.dp, end = 40.dp, top = 5.dp, bottom = 8.dp).height(48.dp).clip(RoundedCornerShape(30.dp)).background(Color(0xFF0E0E10)).padding(4.dp), verticalAlignment = Alignment.CenterVertically) { val items = listOf(Icons.Outlined.Home, Icons.Outlined.WorkspacePremium, Icons.Outlined.EmojiEvents, Icons.Outlined.Settings); items.forEachIndexed { index, icon -> Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(24.dp)).background(if (selected == index) PurpleSoft else Color.Transparent), contentAlignment = Alignment.Center) { IconButton(onClick = { onSelected(index) }) { Icon(icon, null, tint = if (selected == index) Color(0xFFBCA8F4) else Color(0xFF706D74), modifier = Modifier.size(17.dp)) } } } } } }
